
# Maxwell Data — ESG Materiality Decision Support
## UKFinnovator Hackathon — Sustainable Investing Silver Bullet

---

## Quick start

### Option A — Open the frontend directly (no setup needed)
Open `frontend/esg_navigator.html` in any browser. Data is already embedded. Done.

### Option B — Streamlit app
```bash
pip install -r requirements.txt
pip install streamlit plotly
streamlit run app.py
```

### Option C — Regenerate all data from scratch
```bash
pip install -r requirements.txt
cd scripts
python3 run_all.py --skip-ai          # demo mode, no API key needed
# OR
export ANTHROPIC_API_KEY=sk-...
python3 run_all.py                     # full AI pipeline
```

---

## Project structure

```
final_project/
├── app.py                         # Streamlit app
├── requirements.txt
├── frontend/
│   └── esg_navigator.html         # Main frontend — open directly in browser
├── data/
│   ├── ftse100_materiality.csv    # Source: FTSE100 SASB materiality weights
│   ├── sector_heatmaps.json       # Per-sector heatmaps + peer averages
│   ├── sector_dashboard_data.json # Per-company 3-lens scoring (all 26 factors)
│   ├── financial_data.json        # Share price data (needs internet to populate)
│   ├── evidence.json              # AI-retrieved evidence (Stage 1)
│   ├── model_explanations.json    # SHAP attributions (Stage 2)
│   ├── narratives.json            # AI-generated perspectives (Stage 3)
│   ├── pbs_scores.json            # Cameron PBS scores (Stage 6)
│   └── final_dashboard_data.json  # FINAL merged output → consumed by frontend
├── models/
│   ├── model.json                 # Trained XGBoost model
│   └── plots/                     # SHAP visualisation charts
└── scripts/
    ├── run_all.py                 # Orchestrates everything
    ├── build_sector_data.py       # Stage 0: materiality gaps + peer averages
    ├── 00_fetch_financial_data.py # Stage 0b: real share price data
    ├── seed_evidence.py           # Seed evidence (no API key needed for demo)
    ├── 01_fetch_evidence.py       # Stage 1 AI: evidence retrieval via web search
    ├── 02_train_model.py          # Stage 2 AI: XGBoost + SHAP explainability
    ├── 03_generate_narratives.py  # Stage 3 AI: grounded perspective generation
    ├── 04_merge_final.py          # Stage 4: merge into final_dashboard_data.json
    ├── 05_visualize_shap.py       # SHAP plots for pitch deck
    └── 06_compute_pbs.py          # Stage 6: Cameron PBS composite scores

```

---

## The 3 AI stages

**Stage 1** — Claude + web search reads sustainability reports and news per
(company, factor), extracts cited 2-3 sentence summaries + positive/negative/mixed signal.

**Stage 2** — XGBoost on 26 SASB weights. SHAP attributes each factor's
contribution to the model's prediction. With internet: predicts real share price
volatility. Without: predicts a materiality distinctiveness index (demo mode).

**Stage 3** — Three separate Claude calls per factor (Auditor / Corporate /
Investor), each with its own system prompt and audience framing, grounded
strictly in Stage 1 evidence and Stage 2 SHAP values. Never invents numbers.

**Everything else** is deterministic arithmetic:
gap = company_weight − sector_peer_average

---

## New fields added this version

- `z_score` — gap ÷ sector std dev (how unusual vs spread within sector)
- `pbs` — Cameron 4-dimensional score (importance × urgency × conviction × sentiment)

PBS is inspired by Cameron et al. 2025 — the reference paper from Maxwell Data.

Source: FTSE100 SASB financial materiality (March 2025). Not financial advice.
