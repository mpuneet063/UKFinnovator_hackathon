"""
STAGE 6 — PBS score (Cameron 4-dimensional framework), additive.
Reads final_dashboard_data.json BEFORE it's regenerated + evidence.json.
Writes pbs_scores.json consumed by 04_merge_final.py.
"""
import json, os

def rescale_importance(w, lo=0.1, hi=0.9):
    if w == 0: return 0
    return round(1 + 4 * (max(lo, min(hi, w)) - lo) / (hi - lo), 2)

def sentiment_score(direction):
    return {"positive": -1, "mixed": 0, "negative": 1}.get(direction, 0)

def urgency_score(gap, confidence):
    big = abs(gap) >= 0.1
    mid = abs(gap) >= 0.05
    hi  = confidence == "high"
    med = confidence == "medium"
    if big and hi:  return 3
    if mid and med: return 2
    if big or hi:   return 2
    return 1

def conviction_score(confidence):
    return {"high": 3, "medium": 2, "low": 1}.get(confidence, 1)

def compute_pbs(importance, sentiment, urgency, conviction):
    return round(importance * (1 + sentiment) * urgency * conviction, 3)

def main():
    with open("../data/sector_dashboard_data.json") as f:
        companies = json.load(f)

    evidence_lookup = {}
    if os.path.exists("../data/evidence.json"):
        with open("../data/evidence.json") as f:
            for item in json.load(f):
                evidence_lookup[(item["company"], item["factor"])] = item

    pbs_results = []
    for c in companies:
        if c["data_status"] != "ok":
            continue
        company_pbs = {"company": c["company"], "sector": c["sector"], "factors": []}
        for f in c["factors"]:
            mat = f["materiality_weight"]
            if mat == 0:
                continue
            gap = f["gap"]
            ev  = evidence_lookup.get((c["company"], f["factor"]))
            direction  = ev["evidence_direction"] if ev else "mixed"
            confidence = ev["confidence"]         if ev else "low"

            imp  = rescale_importance(mat)
            sent = sentiment_score(direction)
            urg  = urgency_score(gap, confidence)
            conv = conviction_score(confidence)
            pbs  = compute_pbs(imp, sent, urg, conv)

            company_pbs["factors"].append({
                "factor":             f["factor"],
                "gap":                gap,
                "importance":         imp,
                "sentiment":          sent,
                "urgency":            urg,
                "conviction":         conv,
                "pbs_score":          pbs,
                "evidence_available": ev is not None,
            })
        company_pbs["factors"].sort(key=lambda x: -x["pbs_score"])
        pbs_results.append(company_pbs)

    with open("../data/pbs_scores.json", "w") as f:
        json.dump(pbs_results, f, indent=2)
    print(f"Saved ../data/pbs_scores.json — {len(pbs_results)} companies")

if __name__ == "__main__":
    main()
