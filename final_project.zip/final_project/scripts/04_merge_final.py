"""
STAGE 4 — Merge all stages into final dashboard data
Outputs the EXACT schema consumed by esg_navigator.html:

Company: { company, symbol, sector, material_count, factors[] }
Factor:  { factor, weight, peer_avg, gap, direction, color,
           decision, estimate, auditor_view, corporate_view,
           investor_view, uncertainties[], evidence, model, source,
           z_score (new), pbs (new) }
"""

import json
import os

def main():
    with open("../data/sector_dashboard_data.json") as f:
        companies = json.load(f)

    with open("../data/model_explanations.json") as f:
        model_out = json.load(f)
    target_type = model_out["target_type"]
    in_sample_r2 = model_out["in_sample_r2"]
    n_training = model_out["n_training_rows"]
    exp_by_company = {e["company"]: e for e in model_out["explanations"]}

    evidence_by_key = {}
    if os.path.exists("../data/evidence.json"):
        with open("../data/evidence.json") as f:
            for item in json.load(f):
                evidence_by_key[(item["company"], item["factor"])] = item

    narratives_by_key = {}
    if os.path.exists("../data/narratives.json"):
        with open("../data/narratives.json") as f:
            raw = json.load(f)
            items = raw.get("narratives", raw) if isinstance(raw, dict) else raw
            for item in items:
                narratives_by_key[(item["company"], item["factor"])] = item

    pbs_by_key = {}
    if os.path.exists("../data/pbs_scores.json"):
        with open("../data/pbs_scores.json") as f:
            for c in json.load(f):
                for fac in c["factors"]:
                    pbs_by_key[(c["company"], fac["factor"])] = fac

    output_companies = []
    for c in companies:
        if c["data_status"] != "ok":
            continue  # skip unmapped companies entirely

        exp = exp_by_company.get(c["company"])
        shap_by_factor = {}
        if exp:
            for rank, s in enumerate(exp["shap_contributions"]):
                shap_by_factor[s["factor"]] = {
                    "shap_value": s["shap_value"], "shap_rank": rank + 1
                }

        material_factors = [f for f in c["factors"] if f["materiality_weight"] > 0]

        out_factors = []
        for f in c["factors"]:
            # --- differentiated perspective texts ---
            exp_data = f.get("explanation", {})
            nar = narratives_by_key.get((c["company"], f["factor"]))
            if nar:
                auditor_view   = nar.get("auditor_view",   exp_data.get("auditor_view", ""))
                corporate_view = nar.get("corporate_view", exp_data.get("corporate_view", ""))
                investor_view  = nar.get("investor_view",  exp_data.get("investor_view", ""))
                uncertainties  = nar.get("key_uncertainties", [])
                source = "ai_generated"
            else:
                auditor_view   = exp_data.get("auditor_view", "")
                corporate_view = exp_data.get("corporate_view", "")
                investor_view  = exp_data.get("investor_view", "")
                uncertainties  = []
                source = "template"

            # --- evidence ---
            ev = evidence_by_key.get((c["company"], f["factor"]))
            evidence = None
            if ev:
                evidence = {
                    "summary":   ev["evidence_summary"],
                    "direction": ev["evidence_direction"],
                    "confidence": ev["confidence"],
                    "sources":   ev.get("sources", []),
                }

            # --- model ---
            shap_info = shap_by_factor.get(f["factor"])
            model_info = None
            if shap_info:
                model_info = {
                    "target_type": target_type,
                    "shap_value":  round(shap_info["shap_value"], 5),
                    "shap_rank":   shap_info["shap_rank"],
                    "in_sample_r2": in_sample_r2,
                }

            # --- z_score ---
            z_score = f.get("z_score", None)

            # --- pbs ---
            pbs_entry = pbs_by_key.get((c["company"], f["factor"]))
            pbs = None
            if pbs_entry:
                pbs = {
                    "score":              pbs_entry["pbs_score"],
                    "importance":         pbs_entry["importance"],
                    "sentiment":          pbs_entry["sentiment"],
                    "urgency":            pbs_entry["urgency"],
                    "conviction":         pbs_entry["conviction"],
                    "evidence_available": pbs_entry.get("evidence_available", False),
                }

            out_factors.append({
                "factor":        f["factor"],
                "weight":        f["materiality_weight"],
                "peer_avg":      f["peer_group_average"],
                "gap":           f["gap"],
                "direction":     f["direction"],
                "color":         f["consensus_color"],
                "decision":      f["decision"],
                "estimate":      f["estimate"],
                "auditor_view":  auditor_view,
                "corporate_view": corporate_view,
                "investor_view": investor_view,
                "uncertainties": uncertainties,
                "evidence":      evidence,
                "model":         model_info,
                "source":        source,
                "z_score":       z_score,
                "pbs":           pbs,
            })

        output_companies.append({
            "company":       c["company"],
            "symbol":        c["symbol"],
            "sector":        c["sector"],
            "material_count": len(material_factors),
            "factors":        out_factors,
        })

    out = {
        "model_meta": {
            "target_type":     target_type,
            "in_sample_r2":    in_sample_r2,
            "n_training_rows": n_training,
        },
        "companies": output_companies,
    }

    with open("../data/final_dashboard_data.json", "w") as f:
        json.dump(out, f, indent=2)

    n_ev  = sum(1 for k in evidence_by_key)
    n_nar = sum(1 for k in narratives_by_key)
    n_pbs = sum(1 for k in pbs_by_key)
    print(f"Saved ../data/final_dashboard_data.json")
    print(f"  {len(output_companies)} companies (excl. unmapped)")
    print(f"  {n_ev} evidence items / {n_nar} AI narratives / {n_pbs} PBS scores")
    print(f"  Model: {target_type} (R²={in_sample_r2})")

if __name__ == "__main__":
    main()
